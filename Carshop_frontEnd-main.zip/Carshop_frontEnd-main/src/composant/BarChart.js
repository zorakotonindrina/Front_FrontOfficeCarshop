import React from 'react'

function BarChart() {
  return (
    <div>
        <div className="testimonial-person">
            <div className="tab">
                <table>
                    <tr>
                        <th>Categorie</th>
                        <th>Nom Categorie</th>
                    </tr>
                    
                    <tr className="tr">
                        <td>1</td>
                        <td>Exemple</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
  )
}

export default BarChart